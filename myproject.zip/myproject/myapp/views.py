from django.shortcuts import render
from .models import Person

def index(request):
    all_person = Person.objects.all()
    return render(request, 'index.html', {'all_person': all_person})